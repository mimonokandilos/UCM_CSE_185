%% lab02.m uses median_filder.m
%% Introduction to Computer Vision 185
%% Lab 02: For Loop Operation
%% Instructor: Prof. Ming-Hsuan Yang TA: Tiantian Wang & Tsai-Shien Chen
%% Completed by: Mike Monokandilos
%% (x4) 
%Problem 1. Rotate 01.jpg by 45 degrees using forward warping, and
%save as rotate_0.jpg
%Problem 2. Rotate 01.jpg by 45 degrees using backward warping,
%and save as rotate_1.jpg
%Problem 3. Implement median_filter.m for lena_noisy.jpg, use patch
%size = 3 and save the image as median_0.jpg
%Problem 4. Use patch size = 5, and save the image as median_1.jpg




%Problem 1. Rotate 01.jpg by 45 degrees using forward warping, and save as rotate_0.jpg
%Loading images
img01 = imread('01.jpg');
img01(:);

%find dimensions of img
[y_size,x_size,z_size]=size(img01);

%Declaring an array, parameterize angle, x0, y0
I2 = zeros(y_size,x_size,z_size,'uint8');
Q = 45;
x0 = x_size/2;
y0 = y_size/2;

%forward warping**from psudo
for y1 = 1:y_size
    for x1 = 1:x_size
        x2 = cosd(Q)*(x1-x0)+sind(Q)*(y1-y0)+x0;
        y2 = -sind(Q)*(x1-x0)+cosd(Q)*(y1-y0)+y0;                                                
        x2 = round(x2);
        y2 = round(y2);
        if(1<y2 && y_size>=y2 && x_size>=x2 && 1<=x2)
            I2(y2,x2,:) = img01(y1,x1,:);
        end
    end
end       

figure, imshow(I2);
imwrite(I2, 'rotate_0.jpg');
fprintf('Saving rotate_0.jpg... \n');




%Problem 2. Rotate 01.jpg by 45 degrees using backward warping, 
% and save as rotate_1.jpg
img01 = imread('01.jpg');
img01(:);

%find dimensions of img
[y_size,x_size,z_size] = size(img01);

%Declaring an array, parameterize angle, x0, y0
I3 = zeros(y_size,x_size,z_size,'uint8');
Q = 45;
x0 = x_size/2;
y0 = y_size/2;

%backward warping**from psudo
for y1 = 1:y_size
    for x1 = 1:x_size
        x2 = cosd(Q)*(x1 - x0)-sind(Q)*(y1 - y0)+x0;
        y2 = sind(Q)*(x1 - x0)+cosd(Q)*(y1 - y0)+y0;                                                   
        x2 = round(x2);
        y2 = round(y2);
        if(1<y2 && y_size>=y2 && x_size>=x2 && 1<=x2)
            I3(y1,x1,:) = img01(y2,x2,:);
        end
    end
end       

figure, imshow(I3);
imwrite(I3, 'rotate_1.jpg');
fprintf('Saving rotate_1.jpg... \n');




%Problem 3: call median filter with patch size 3 save as median_0
img02 = imread('lena_noisy.jpg');
patch_size = [3,3];
img_median = median_filter(img02, patch_size);

figure, imshow(img_median)
imwrite(img_median, 'median_0.jpg');
fprintf('Saving median_0.jpg... \n');




%Problem 4: call median filter Use patch size 5 and save as median_1
img02 = imread('lena_noisy.jpg');
patch_size = [5,5];
img_median = median_filter(img02, patch_size);

figure, imshow(img_median)
imwrite(img_median, 'median_1.jpg');
fprintf('Saving median_1.jpg... \n');
