%% median_filder.m supplies lab02.m
%% Introduction to Computer Vision 185
%% Lab 02: For Loop Operation
%% Instructor: Prof. Ming-Hsuan Yang TA: Tiantian Wang & Tsai-Shien Chen
%% Completed by: Mike Monokandilos
%img=lena_noisy
function output = median_filter(lena_noisy_img, patch_size)
    I1 = im2double(imread('lena_noisy.jpg'));
    I2 = zeros(size(I1));%Initalize a zero matrix of size I1
    
    %The shift1 or 2, depending on patch size is 3 or 5 respectively 
    % considered (filter size)?
    shift_v = floor(patch_size(2)/2);
    shift_u = floor(patch_size(1)/2);  
    
    %Nested for loop to iterate through the entire image
    for u = 1 + shift_u:size(I1,2) - shift_u
        for v = 1 + shift_v:size(I1,1) - shift_v
            x1 = u - shift_u; 
            x2 = u + shift_u;
            y1 = v - shift_v; 
            y2 = v + shift_v;  
            
            %take the median of the patch after we make 2D matrix into 1D 
            patch = I1(y1:y2,x1:x2);
            patch = patch(:);          
            value = median(patch);
            I2(v,u) = value; 
        end
    end
        output = I2;
end