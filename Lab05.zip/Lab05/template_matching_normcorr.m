%% template_matching_normcorr.m

%% Introduction to Computer Vision 185
%% Lab 05
%% Instructor: Prof. Ming-Hsuan Yang TA: Tiantian Wang & Tsai-Shien Chen
%% Completed by: Mike Monokandilos

function [returning, match] = template_matching_normcorr(img, template, threshold)
    
    returning = zeros(size(img));
    size_x = size(img, 2);
    size_y = size(img, 1);
    hsize = size(template, 1);
    % shift based on hsize / patch size
    shift = floor(hsize/2);
    for u = 1 + shift : size_x - shift
        for v = 1 + shift :size_y - shift 
            patch = img(v-shift:v+shift, u-shift:u+shift);
            % NormCorr
            patch_vec = patch(:);
            patch_norm = patch_vec - mean(patch_vec);
            patch_norm = patch_norm / norm(patch_norm);
            template_vec = template(:);
            template_norm = template_vec - mean(template_vec);
            template_norm = template_norm / norm(template_norm);
            normcorr = dot(patch_norm, template_norm);
            returning(v, u) = normcorr;
        end
    end
    match = (returning > threshold);
end
