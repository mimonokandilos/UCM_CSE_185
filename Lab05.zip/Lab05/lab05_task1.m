%% lab05_task1.m
%% Introduction to Computer Vision 185
%% Lab 05
%% Instructor: Prof. Ming-Hsuan Yang TA: Tiantian Wang & Tsai-Shien Chen
%% Completed by: Mike Monokandilos
%%TASKLIST
%implement Gaussian Pyramid and Laplacian Pyramid in
%lab05_task1.m (use lena.jpg as input and save the output images as Gaussian_scale1.jpg ~ Gaussian_scale5.jpg and Laplacian_scale1.jpg ~ Laplacian_scale5.jpg)
%2. Implement template_matching_SSD.m, and try to find the best threshold value for einstein1.jpg and
%einstein2.jpg (save the output images as einstein1_ssd_output.jpg, einstein1_ssd_match.jpg, einstein2_ssd_output.jpg, einstein2_ssd_match.jpg)
%3. Implement template_matching_normcorr.m, and try to find the best threshold value for einstein1.jpg and
%einstein2.jpg (save the output images as einstein1_normcorr_output.jpg, einstein1_normcorr_match.jpg, einstein2_normcorr_output.jpg, einstein2_normcorr_match.jpg)
%4. Upload all output images and lab05_task1.m, lab05_task2.m, template_matching_SSD.m, and template_matching_normcorr.m separately.

%%PROBLEM 1

%implememt gaussian scale and lablacian scale 1-5
img = im2double(imread('lena.jpg'));
sigma = 2.0;
hsize = 7;
scale = 5;


I = img;
H = fspecial('gaussian', hsize, sigma);
for s = 1 : scale
    %Gaussian filter
    var = floor(hsize/2);    
    %save or show image
    img_test = imfilter(I,H);
    imwrite(I, sprintf('Gaussian_scale%d.jpg', s));
    %Down-sampling    
   % imresize
   I = imresize(I,1/2);
   %imshow(I);
end

%Laplacian Pyramid
I = img;
for s = 1 : scale
    %Gaussian filtering
    filter = imfilter(I, H);
    %Laplacian filtering
    Laplace_test = I - filter;
    %Save or show image
    imwrite(Laplace_test + 0.5, sprintf('Laplacian_scale%d.jpg',s));    
    %Down-Sampling
    I = imresize(I, 1/2);
end

