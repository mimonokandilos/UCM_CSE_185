%%lab05_task2.m


%%PROBLEM 2 
%ein1
img1 = im2double(imread('einstein1.jpg'));
img2 = im2double(imread('einstein2.jpg'));
temp = im2double(imread('template.jpg'));

%ein 1
%SSD Template matching
threshold = 25;
[output, match] = template_matching_SSD(img1, temp, threshold);

figure, imshow(output ./ max(output(:))); title('SSD output');
figure, imshow(match); title('SSD match');

imwrite(output ./ max(output(:)), sprintf('%s_ssd_output.jpg', 'einstein1') );
imwrite(match, sprintf('%s_ssd_match.jpg', 'einstein1') );


%Cross Correlation
threshold1 = 0.5;
[output, match] = template_matching_normcorr(img1, temp, threshold1);

figure, imshow(output ./ max(output(:))); title('NormCorr output');
figure, imshow(match); title('NormCorr match');

imwrite(output ./ max(output(:)), sprintf('%s_normcorr_output.jpg', 'einstein1') );
imwrite(match, sprintf('%s_normcorr_match.jpg', 'einstein1') );

%ein 2


%SSD Template matching
threshold = 36;
[output, match] = template_matching_SSD(img2, temp, threshold);

figure, imshow(output ./ max(output(:))); title('SSD output');
figure, imshow(match); title('SSD match');

imwrite(output ./ max(output(:)), sprintf('%s_ssd_output.jpg', 'einstein2') );
imwrite(match, sprintf('%s_ssd_match.jpg', 'einstein2') );


%Cross Correlation
threshold1 = 0.5;
[output, match] = template_matching_normcorr(img2, temp, threshold1);

figure, imshow(output ./ max(output(:))); title('NormCorr output');
figure, imshow(match); title('NormCorr match');

imwrite(output ./ max(output(:)), sprintf('%s_normcorr_output.jpg', 'einstein2') );
imwrite(match, sprintf('%s_normcorr_match.jpg', 'einstein2') );


