%% Introduction to Computer Vision 185
%% Instructor: Prof. Ming-Hsuan Yang TA: Tiantian Wang & Tsai-Shien Chen
%% Completed by: Mike Monokandilos
%%
%% Lab 06 
%% file: Lab06_face.m
%% part of: Lab06_edge.m, sobel_feature.m, multiscale_sobel_feature.m


load('att_face.mat');
num_testing = size(id_testing, 1);
num_training = size(id_training, 1);
id_predict = zeros(size(id_testing));
%rotate scale from [1,2,3]
scale = 1;

for i = 1:num_testing
    %% extract testing image
    img_test = face_testing(:,:,i);
    vec_test = multiscale_sobel_feature(img_test, scale);
    
    error = zeros(num_training, 1);
    for j =1:num_training
        
        %% extract training image
        img_train = face_training(:,:,j);
        vec_train = multiscale_sobel_feature(img_train, scale);
        
        %% compute the square error between feature vectors
        diff = vec_train - vec_test;
        error(j) = sum (diff .^2);
    end
    %% find the image id with minimal error
    [~, min_id] = min(error);
    id_predict(i) = min_id;
end

%% compute accuracy
accuracy = sum(id_testing == id_predict)/num_testing;
fprintf('Accuracy = %f\n', accuracy);


%Using gradient magnitude as features:
%--------------------------------------%
% Scale |  Accuracy
%---------------------------------------%
%   1   |   Accuracy = 0.5313
%---------------------------------------%
%   2   |   Accuracy = 0.5500
%---------------------------------------%
%   3   |  Accuracy = 0.593750
%---------------------------------------%
%Using gradient orientation as features:
%---------------------------------------%
% Scale |  Accuracy
%---------------------------------------%
%   1   |   Accuracy = 0.5563
%---------------------------------------%
%   2   |   
%---------------------------------------%
%   3   |   
%---------------------------------------%