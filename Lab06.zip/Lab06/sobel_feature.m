%% Introduction to Computer Vision 185
%% Instructor: Prof. Ming-Hsuan Yang TA: Tiantian Wang & Tsai-Shien Chen
%% Completed by: Mike Monokandilos
%%
%% Lab 06 
%% file: sobel_feature.m
%% part of: Lab06_edge.m, Lab06_face.m, multiscale_sobel_feature.m


function [magnitude, orientation] = sobel_feature(img)
    %horizontal edge
    Hy = [1, 2, 1; 0, 0, 0; -1, -2, -1];
    %vertical edge
    Hx = [1, 0, -1; 2, 0, -2; 1, 0, -1];   
   
    %horizontal edge & %vertical edge
    sobel_h = imfilter(img, Hy);
    sobel_v = imfilter(img, Hx);

    %calculate magnitude and orientation
    magnitude = sqrt(sobel_h.^2 + sobel_v.^2);
    orientation = atan2(sobel_h, sobel_v);
end