%% Introduction to Computer Vision 185
%% Instructor: Prof. Ming-Hsuan Yang TA: Tiantian Wang & Tsai-Shien Chen
%% Completed by: Mike Monokandilos
%%
%% Lab 06 
%% file: multiscale_sobel_feature.m
%% part of: Lab06_edge.m, Lab06_face.m, sobel_feature.m


function feature = multiscale_sobel_feature(img, scale)
    % initialize feature vector
    feature = [];
    
    for i = 1:scale
        [magnitude, orientation] = sobel_feature(img);
        % compute sobel feature
        f = magnitude(:);
        
        % concatenate feature vector
        feature = cat(1, feature, f(:));
        
        % down-sample image by 2
        img = imresize(img, 1/2);
    end
end