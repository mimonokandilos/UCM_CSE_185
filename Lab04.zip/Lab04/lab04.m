%% lab04.m uses hybrid_image.m, separate_frequency.m
%% Introduction to Computer Vision 185
%% Lab 04
%% Instructor: Prof. Ming-Hsuan Yang TA: Tiantian Wang & Tsai-Shien Chen
%% Completed by: Mike Monokandilos
 
%Problem 1: attached separate_frequency.m

%Problem 2: Ratio = 0.1 for lenalow and lenahigh
img1 = im2double(imread('lena.jpg'));
%imshow(img1);
ratio1 = 0.1;
[low_pass_1, high_pass_1] = separate_frequency(img1, ratio1);
imwrite(low_pass_1, 'lena_low_0.1.jpg')
imwrite(high_pass_1+0.5, 'lena_high_0.1.jpg')
%imshow(low_pass_1)
%imshow(high_pass_1+0.5)

%Problem 3: Ratio = 0.2 for lenalow and lenahigh
ratio2 = 0.2;
img1 = im2double(imread('lena.jpg'));
[low_pass_2, high_pass_2] = separate_frequency(img1, ratio2);
imwrite(low_pass_2, 'lena_low_0.2.jpg')
imwrite(high_pass_2+0.5, 'lena_high_0.2.jpg')
%imshow(low_pass_2)
%imshow(high_pass_2+0.5)
%Problem 4: attached hybrid_image.m

%Problem 5: Create a hybrid version with low marilyn and high einstein
name1 = 'marilyn.jpg';
name2 = 'einstein.jpg';
img2 = im2double(imread(name1));
img3 = im2double(imread(name2));
ratio = 0.3;
combo1 = hybrid_image(img2, img3, ratio);
%figure, imshow(mar_ein);
imwrite(combo1, 'hybrid_1.jpg');
%imshow(mar_ein)

%Problem 6: Create a hybrid version with low einstein and high marilyn
ratio = 0.25;
combo2 = hybrid_image(img3, img2, ratio);
%figure, imshow(ein_mar);
imwrite(combo2, 'hybrid_2.jpg')
%imshow(ein_mar)
%Problem images are attached 