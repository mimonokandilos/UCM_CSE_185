%%  hybrid_image.m uses separate_frequency.m, lab04.m 
%% Introduction to Computer Vision 185
%% Lab 04
%% Instructor: Prof. Ming-Hsuan Yang TA: Tiantian Wang & Tsai-Shien Chen
%% Completed by: Mike Monokandilos
%provided by TA slides
function merged_image = hybrid_image(img1, img2, ratio)
    [low_frequency_img, high_frequency_img] = separate_frequency(img1, ratio);
    [low_frequency_img2, high_frequency_img2] = separate_frequency(img2, ratio);
    merged_image = low_frequency_img + high_frequency_img2;
end