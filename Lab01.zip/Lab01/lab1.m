%% Mike Monokandilos
%% Computer Vision
%% Lab 01
%% clear first
clear;clc;


%% [START] Problem 1
%% load image
img1_p1 = imread("01.jpg");
%% [TEST] for testing uncomment next line ~
%figure, imshow(img1_p1);
%% zero out second channel - remove green
img1_p1(:,:,2) = 0;
%% [TEST] for testing uncomment next line ~
% figure, imshow(img1_p1);
%% save image
imwrite(img1_p1, "green.jpg");
fprintf("Problem 1: successfully saving green.jpg...\n");
%% [EOP] Problem 1


%% [START] Problem 2
%% load image
img1_p2 = imread("01.jpg");
%% [TEST] for testing uncomment next line ~
% figure, imshow(img1_p2);
%% split for each color -> typeCast to double
img1_r = double(img1_p2(:,:,1)) / 255.0;
img1_g = double(img1_p2(:,:,2)) / 255.0;
img1_b = double(img1_p2(:,:,3)) / 255.0;
greyimg_p2 = 0.299 * img1_r + 0.587 * img1_g + 0.114 * img1_b;
%% [TEST] for testing uncomment next line ~
% figure, imshow(p2grey);
%% save image
imwrite(greyimg_p2, "grey.jpg");
fprintf("Problem 2: successfully saving grey.jpg...\n");
%% [EOP] Problem 2


%% [START] Problem 3
img1_p3 = imread("01.jpg");
rotated_p3 = imrotate(img1_p3, 90);
%% [TEST] for testing uncomment next line ~
% figure, imshow(img1_p3);
%% save image
imwrite(rotated_p3, "rotate.jpg");
fprintf("Problem 3: successfully saving rotate.jpg...\n");
%% [EOP] Problem 3


%% [START] problem 4
%% crop top left corner(30,100) & bottom right croner(270,300)
%%import the image
img1_p4 = imread("01.jpg");
%% [TEST] for testing uncomment next line ~
% figure, imshow(img1_p4)
%% crop image
cropped_p4 = img1_p4(30:270, 100:300, :);
%% [TEST] for testing uncomment next line ~
% figure, imshow(cropped_p4);
%% save image
imwrite(cropped_p4, "crop.jpg");
fprintf("Problem 4: successfully saving crop.jpg...\n");
%% [EOP] Problem 4


%% [START] Problem 5
% flip the image horizontally
%% import the image
img1_p5 = imread("01.jpg");
%% [TEST] for testing uncomment next line ~
% figure, imshow(img1_p5)
flipped_p5 = flip(img1_p5,2);
%% [TEST] for testing uncomment next line ~
% figure, imshow(flipped5);
%% save image
imwrite(flipped_p5, "flip.jpg");
fprintf("Problem 5: successfully saving flip.jpg...\n");
%% [EOP] problem 5


%% [START] problem 6
%% import the images
img1_p6 = imread("01.jpg");
img2_p6 = imread("02.jpg");
img3_p6 = imread("03.jpg");
img4_p6 = imread("04.jpg");
%% [TEST] for testing uncomment next line ~
% figure, imshow(img1_p6)
% figure, imshow(img6_2)
% figure, imshow(img6_3)
% figure, imshow(img6_4)
%% setup parent matrix then combine
combine_p6 = zeros(300 * 2 + 10, 400 * 2 + 10, 3, 'uint8');
%% input first picture[matrix form]
combine_p6(1:300,1:400, :) = img1_p6;
%% input second picture matrix
combine_p6(1:300,411:810, :) = img2_p6;
%% input third picture matrix
combine_p6(311:610,1:400, :) = img3_p6;
%% input fourth picture matrix
combine_p6(311:610,411:810, :) = img4_p6;
%% [TEST] for testing uncomment next line ~
% figure, imshow(parent);
%% save image
imwrite(combine_p6, "combine.jpg");
fprintf("Problem 6: successfully saving combine.jpg...\n");
%% [EOF] Problem 6


%% [START] problem 7
%flip the image horizontally
%% import the image
img5_p7 = imread("05.jpg");
img6_p7 = imread("06.jpg");
%% take dimensions of both pics
x_p7 = size(img5_p7, 1);  y_p7 = size(img5_p7, 2);  z_p7 = size(img5_p7, 3);
x1_p7 = size(img6_p7, 1); y1_p7 = size(img6_p7, 2); z1_p7 = size(img6_p7, 3);
%%If Dimensions are equal
if x_p7 == x1_p7 && y_p7 == y1_p7 && z_p7 == z1_p7
    %% [TEST] for testing uncomment next line ~
    % figure, imshow(img5_p7);
    % figure, imshow(img6_p7);
    %% convert Matricies to Vectors
    img5_v = img5_p7(:);
    img6_v = img6_p7(:);
    %% AVG 2 Vectors
    avg_p7 = ((img5_v + img6_v) / 2);
    %% convert Vectors to Matrices
    avg_p7 = reshape(avg_p7, x_p7, y_p7, []);
    %% [TEST] for testing uncomment next line ~
    % figure, imshow(avg_p7);
    %% save image
    imwrite(avg_p7, "average.jpg");
    fprintf("Problem 7: successfully saving average.jpg...\n");
else
    fprintf("The dimensions of the two pictures do not match\n\n These are the dimensions Picture 1: %i %i\n These are the dimensions Picture 2: %i %i\n\n Please input pictures with matching dimensions",x,y,x1,y1);
end
%% [EOF] problem 7